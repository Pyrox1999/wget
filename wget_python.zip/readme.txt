This App downloads all files from the server. So don't use it on websites, where you don't have the permission! Enter in the begin the web-adress, and the App starts to download. Before the download start, the app generate a folder in the directory of the app named "doanloads" where the files come in.

Music by ZetaZero